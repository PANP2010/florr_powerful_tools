# Florr.io Mob 检测器训练包

## 📦 包内容

```
upload_package/
├── dataset/                    # 数据集目录
│   ├── val/                   # 验证集
│   │   └── labels/           # 验证集标签
│   ├── data.yaml             # 本地数据集配置
│   └── data_cloud.yaml       # 云端数据集配置模板
├── training_scripts/          # 训练脚本
│   ├── train_mob_detector_colab.py      # Python训练脚本
│   └── train_mob_detector_notebook.ipynb # Jupyter Notebook
└── README.md                  # 本文件
```

## ⚠️ 重要说明

当前数据集只包含验证集（val），**缺少训练集（train）**。您需要准备完整的训练数据集。

## 📋 数据集准备步骤

### 1. 创建数据集目录结构

```bash
dataset/
├── train/
│   ├── images/        # 训练图片（.jpg/.png）
│   └── labels/        # 训练标签（.txt，YOLO格式）
├── val/
│   ├── images/        # 验证图片
│   └── labels/        # 验证标签
└── data.yaml          # 数据集配置
```

### 2. 准备训练数据

#### 方法A：使用现有数据生成工具

如果您有数据生成脚本，运行它来生成训练数据：

```bash
# 示例：使用合成数据生成器
python generate_synthetic_data.py --output dataset/train
```

#### 方法B：手动准备数据

1. **收集图片**：从游戏中截图或使用现有图片
2. **标注数据**：使用标注工具（如 LabelImg、CVAT）
3. **转换格式**：确保标签为 YOLO 格式

### 3. YOLO 标签格式

每个图片对应一个 `.txt` 文件，格式如下：

```
class_id center_x center_y width height
```

示例：
```
0 0.5 0.5 0.3 0.4
1 0.2 0.3 0.1 0.15
```

所有坐标都是归一化的（0-1之间）。

### 4. 修改 data.yaml

根据您的数据集路径修改 `data_cloud.yaml`：

```yaml
# Kaggle
path: /kaggle/input/your-dataset-name

# Colab
path: /content/drive/MyDrive/your-dataset-name

# 恒源云
path: /root/dataset

train: train/images
val: val/images

nc: 81  # 类别数量
names:
  0: ant_baby
  1: ant_egg
  # ... 其他类别（见 data_cloud.yaml）
```

## 🚀 上传到训练平台

### Kaggle

#### 方法1：网页上传

1. 访问 https://www.kaggle.com/datasets
2. 点击 "New Dataset"
3. 上传整个 `dataset` 文件夹
4. 设置标题和可见性（Private/Public）

#### 方法2：Kaggle API

```bash
# 安装 Kaggle API
pip install kaggle

# 配置 API Key（从 https://www.kaggle.com/settings 获取）
mkdir -p ~/.kaggle
mv kaggle.json ~/.kaggle/
chmod 600 ~/.kaggle/kaggle.json

# 创建数据集
cd upload_package
kaggle datasets init -p dataset/
# 编辑生成的 meta-data 文件
kaggle datasets create -p dataset/
```

### Google Colab

#### 方法1：Google Drive 上传

1. 打开 https://drive.google.com/
2. 创建文件夹（如 `florr_dataset`）
3. 上传 `dataset` 文件夹内容
4. 在 Colab 中挂载 Drive：
   ```python
   from google.colab import drive
   drive.mount('/content/drive')
   ```

#### 方法2：直接上传到 Colab

```python
from google.colab import files
uploaded = files.upload()  # 选择压缩包上传
!unzip florr_dataset.zip
```

### 恒源云

#### 使用 SCP 上传

```bash
# 压缩数据集
cd upload_package
zip -r florr_dataset.zip dataset/

# 上传到服务器
scp florr_dataset.zip root@your-server-ip:/root/

# SSH 登录后解压
ssh root@your-server-ip
cd /root
unzip florr_dataset.zip
```

## 🎯 开始训练

### Kaggle

1. 创建新 Notebook
2. 上传 `training_scripts/train_mob_detector_notebook.ipynb`
3. 添加数据集（右侧 Add Data）
4. 修改数据集路径
5. 运行训练

### Colab

1. 打开 https://colab.research.google.com/
2. 上传 `training_scripts/train_mob_detector_notebook.ipynb`
3. 设置 GPU 运行时
4. 挂载 Google Drive
5. 运行训练

### 恒源云

```bash
# SSH 登录后
cd /root
python training_scripts/train_mob_detector_colab.py \
    --data /root/dataset/data_cloud.yaml \
    --epochs 100 \
    --batch 32
```

## 📊 预期训练时间

| 平台 | GPU | 数据集大小 | 训练时间 |
|------|-----|-----------|----------|
| Kaggle | P100 | 1000张 | 2-3小时 |
| Colab | T4 | 1000张 | 2-3小时 |
| 恒源云 | 3090 | 1000张 | 1小时 |

## 🔧 常见问题

### Q: 数据集太小怎么办？
A: 建议至少准备 500-1000 张训练图片。可以使用数据增强或合成数据。

### Q: 如何生成合成数据？
A: 使用项目中的数据生成脚本：
```bash
python generate_synthetic_data_v3.py --output dataset/train --count 1000
```

### Q: 标签格式错误？
A: 确保标签文件格式正确：
- 每行一个目标
- 格式：`class_id center_x center_y width height`
- 所有值在 0-1 之间

## 📞 需要帮助？

如果遇到问题，请检查：
1. 数据集目录结构是否正确
2. `data.yaml` 路径是否正确
3. 图片和标签是否匹配
4. GPU 是否可用

祝训练顺利！🚀
